import media

toy_story = media.Movie("Toy Story", "A story of a boy and his toys that come to life",
                    "http://upload.wikimedia.org/wikipedia/en/1/13/Toy_story.jpg",
                    "https://ww.youtube.com/watch?v=vwyZH85NQC4")

avatar = media.Movie("Avatar", "A marine on an alien planet",
                  "http://upload.wikimedia.org/wikipedia/en/b/b0/Avatar-Teaser-Poster.jpg",
                  "https://www.youtube.com/watch?v=-9ceBgWV8io")

school_of_rock = media.Movie("School of Rock", "Storyline",
                          "http://upload.wikimedia.org/wikipedia/en/1/11/School_of_Rock_Poster.jpg",
                          "https://www.youtube.com/watch?v=3PsUJFEBC74")

ratatouille = media.Movie("Ratatouille", "Storyline",
                       "http://upload.wikimedia.org/wikipedia/en/5/50/RatatouillePoster.jpg",
                       "https://www.youtube.com/watch?v=c3sBBRxDAqk")

midnight_in_paris = media.Movie("Midnight in Paris", "Storyline",
                             "http://upload.wikimedia.org/wikipedia/en/9/9f/Minight_in_Paris_Poster.jpg",
                             "https://www.youtube.com/watch?v=atLg2wQQxvU")

hunger_games = media.Movie("Hunger Games", "Storyline",
                        "http://upload.wikimedia.org/wikipedia/en/4/42/HungerGamesPoster.jpg",
                        "https://www.youtube.com/watch?v=PbA63a7H0bo")


# print(avatar.storyline)

# avatar.show_trailer()